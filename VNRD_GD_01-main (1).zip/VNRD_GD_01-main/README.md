# VNRD_GD_01
https://www.figma.com/proto/sL7nzpiqqtIqE2IWSBkptE/ABC?type=design&node-id=60-203&t=cFUshWEkhnWlr1t2-1&scaling=scale-down&page-id=0%3A1&starting-point-node-id=7%3A16&show-proto-sidebar=1&mode=design
