function signin(event) {
    event.preventDefault();

    let signinEmail = document.getElementById("signinEmail").value;
    let signinPassword = document.getElementById("signinPassword").value;

    let user = users.find(u => u.email === signinEmail && u.password === signinPassword);

    if (user) {
        alert("Login successful!");
    } else {
        alert("Invalid email or password. Please try again.");
    }

    document.getElementById("signinForm").reset();
}
