// Get references to the DOM elements
const locationDataDiv = document.getElementById('location-data');
const getLocationButton = document.getElementById('get-location');

// Function to display location data
function displayLocationData(data) {
    locationDataDiv.textContent = `
        Latitude: ${data.coords.latitude }
        Longitude: ${data.coords.longitude}
        Accuracy: ${data.coords.accuracy} meters
    `;
}

// Function to handle geolocation errors
function handleLocationError(error) {
    const errorMessage = error.code === 1 ?
        'Permission denied' :
        error.code === 2 ?
            'Location unavailable' :
            'Timeout occurred';
    locationDataDiv.textContent = `Error: ${errorMessage}`;
}

// Add event listener to the button
getLocationButton.addEventListener('click', () => {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(displayLocationData, handleLocationError);
    } else {
        locationDataDiv.textContent = 'Geolocation is not supported by your browser.';
    }
});
