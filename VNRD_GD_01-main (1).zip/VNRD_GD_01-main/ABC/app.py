from flask import Flask, render_template
import threading
import time
from zzz_sound import loud_bell


app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

def play_sound():
    loud_bell.play_loud_bell_sound()

if __name__ == '__main__':
    sound_thread = threading.Thread(target=play_sound)
    sound_thread.start()
    app.run(debug=True, use_reloader=False)
