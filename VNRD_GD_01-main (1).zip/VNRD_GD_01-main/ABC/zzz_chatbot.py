import random

SAFETY_TIPS = {
    "trust_instincts": "Trust your instincts. If you feel unsafe, seek help immediately.",
    "walking_alone": "Avoid walking alone, especially at night. Use well-lit and populated areas.",
    "share_location": "Share your location with trusted contacts when traveling alone.",
    "self_defense": "Familiarize yourself with self-defense techniques and tools.",
    "ride_sharing": "Be cautious when using ride-sharing services. Verify the driver and vehicle details before getting in.",
    "parking_garage": "Park in well-lit areas and avoid parking near large vans or trucks. Have your keys ready and check the backseat before getting in your car.",
    "elevator": "Stand near the buttons in case you need to press the emergency button. If you feel uncomfortable, exit the elevator at the next floor.",
    "public_transportation": "Sit near other people and avoid isolated areas. Keep your belongings close and be aware of your surroundings.",
    "social_events": "Stay with a group of people you trust. Don't leave your drink unattended and be cautious of accepting drinks from strangers.",
    "home_safety": "Keep your doors and windows locked, even when you're home. Install a security system if possible. Don't share your address or personal information online."
}

EMERGENCY_NUMBERS = {
    "police": "Call 911 or your local emergency number for immediate assistance.",
    "ambulance": "Dial 911 or your local emergency number if you require medical assistance.",
    "women's_helpline": "Call the national women's helpline for support and assistance.",
    "campus_safety": "Contact campus safety or security if you are a student or staff member at a university or college."
}

COMMON_SCENARIOS = {
    "parking_garage": "parking",
    "elevator": "elevator",
    "public_transportation": "transportation",
    "social_events": "events",
    "home_safety": "home"
}

FEELING_SUSPICIOUS = {
    "stranger": "If you feel suspicious about a stranger, trust your instincts and avoid them. Cross the street or enter a public place if necessary.",
    "car": "If a car is following you, don't go home. Go to a crowded area or a police station. Try to remember the license plate number and description of the car and people inside.",
    "stalker": "If you feel like you're being stalked, document everything. Keep a record of times, dates, locations, and details of incidents. Consider contacting the police."
}

def get_random_tips(tips: dict, num_tips: int = 3) -> list:
    """Return a list of randomly selected tips from the given dictionary."""
    tips_list = list(tips.values())
    random.shuffle(tips_list)
    return tips_list[:num_tips]

def chat_logic(user_input: str) -> str:
    """Run the chatbot."""
    print("Welcome to Women's Safety Chatbot!")
    print("You can ask for safety tips, emergency numbers, or type 'exit' to end the conversation.")
    
    while True:
        user_input = input("You: ").lower()
        
        if user_input == "exit":
            print("Women's Safety Chatbot: Goodbye! Stay safe!")
            break
        elif any(word in user_input for word in {"safety", "tips"}):
            tips = get_random_tips(SAFETY_TIPS)
            print("Women's Safety Chatbot: Here are some safety tips:")
            for tip in tips:
                print(tip)
        elif any(word in user_input for word in {"emergency", "numbers"}):
            print("Women's Safety Chatbot: Here are some emergency numbers:")
            for service, number in EMERGENCY_NUMBERS.items():
                print(f"{service.capitalize()}: {number}")
        elif "help me" in user_input:
            print("Women's Safety Chatbot: If you're in immediate danger, call 911 or your local emergency number. Stay on the line and provide your location.")
        elif "save me" in user_input:
            print("Women's Safety Chatbot: If you feel threatened, seek help from nearby individuals or establishments. If necessary, call 911 or your local emergency number.")
        elif "i'm in danger" in user_input:
            print("Women's Safety Chatbot: If you're in danger, try to stay calm and assess your surroundings. Seek help from authorities or trusted individuals immediately.")
        elif "not feeling safe" in user_input:
            print("Women's Safety Chatbot: Trust your instincts. If you're not feeling safe, consider moving to a public place or contacting someone you trust for assistance.")
        elif "danger" in user_input:
            print("Women's Safety Chatbot: If you perceive danger, prioritize your safety. Remove yourself from the situation if possible and seek assistance from law enforcement or trusted contacts.")
        elif "feeling like someone is following" in user_input:
            print("Women's Safety Chatbot: If you suspect someone is following you, stay alert and try to reach a safe location. Consider contacting authorities or seeking help from nearby individuals.")
        elif "feeling like i'm not safe" in user_input:
            print("Women's Safety Chatbot: If you feel unsafe, trust your instincts and take necessary precautions. Consider reaching out to friends, family, or authorities for support.")
        elif "help" in user_input:
            scenario = None
            for word in COMMON_SCENARIOS:
                if word in user_input:
                    scenario = COMMON_SCENARIOS[word]
                    break
            if scenario:
                if scenario in SAFETY_TIPS:
                    print("Women's Safety Chatbot: Here are some safety tips for", scenario.replace("_", " ") + ":")
                    print(SAFETY_TIPS[scenario])
                elif scenario in FEELING_SUSPICIOUS:
                    print("Women's Safety Chatbot: Here are some tips for feeling suspicious:")
                    print(FEELING_SUSPICIOUS[scenario])
                else:
                    print("Women's Safety Chatbot: I'm sorry, I don't have tips for that scenario.")
            else:
                print("Women's Safety Chatbot: I'm sorry, I didn't understand that. Could you specify a scenario?")
        else:
            print("Women's Safety Chatbot: I'm sorry, I didn't understand that. Type 'safety tips', 'emergency numbers', or 'help' to get started.")

if __name__ == '__main__':
    chat_logic()
    