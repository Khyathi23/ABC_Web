let users = [];

function signup(event) {
    event.preventDefault();

    let username = document.getElementById("username").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    let conpassword = document.getElementById("conpassword").value;

    if (password !== conpassword) {
        alert("Passwords do not match");
        return;
    }

    let user = { username, email, password };
    users.push(user);

    alert("Signup successful! Now you can sign in.");
    document.getElementById("signupForm").reset();
}
