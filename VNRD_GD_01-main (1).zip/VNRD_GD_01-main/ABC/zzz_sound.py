# loud_bell.py

import pygame
import sys

def play_loud_bell_sound():
    # Initialize Pygame mixer
    pygame.mixer.init()

    # Load the bell sound
    bell_sound = pygame.mixer.Sound(r"C:\Users\patha\Downloads\mixkit-casino-bells-reward-1981.wav")

    # Set the volume
    bell_sound.set_volume(1.0)  # Full volume

    # Play the sound
    bell_sound.play(loops=-1)

if __name__ == "__main__":
    # Play the sound when the script is clicked
    play_loud_bell_sound()
    while pygame.mixer.get_busy():
        pygame.time.Clock().tick(10)
