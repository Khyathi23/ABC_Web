document.addEventListener("DOMContentLoaded", function () {
    // your code here
  
    // Example of adding functionality to the form
    document
      .querySelector("#signup form")
      .addEventListener("submit", function (event) {
        event.preventDefault();
  
        // Get the form data
        var formData = new FormData(event.target);
  
        // Send the form data to a server
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "/submit-form");
        xhr.send(formData);
  
        // Show a message to the user
        alert("Thank you for signing up!");
  
        // Clear the form
        event.target.reset();
      });
  
    // Example of adding functionality to the navigation bar
    document
      .querySelector("header nav ul")
      .addEventListener("click", function (event) {
        if (event.target.tagName.toLowerCase() === "a") {
          var href = event.target.getAttribute("href");
          var target = document.querySelector(href);
          target.scrollIntoView({ behavior: "smooth" });
        }
      });
  });